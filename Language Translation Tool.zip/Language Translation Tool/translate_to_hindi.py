from transformers import MarianMTModel, MarianTokenizer

# Load the model and tokenizer for English to Hindi translation
model_name = 'Helsinki-NLP/opus-mt-en-hi'
tokenizer = MarianTokenizer.from_pretrained(model_name)
model = MarianMTModel.from_pretrained(model_name)

def translate(text, model, tokenizer):
    # Tokenize the input text
    inputs = tokenizer.encode(text, return_tensors="pt")
    
    # Perform the translation
    translated = model.generate(inputs, max_length=512)
    
    # Decode the translated text
    translated_text = tokenizer.decode(translated[0], skip_special_tokens=True)
    
    return translated_text

# Example usage
if __name__ == "__main__":
    # Take user input
    text = input("Enter text to translate into Hindi: ")
    translated_text = translate(text, model, tokenizer)
    print(f"Original text: {text}")
    print(f"Translated text: {translated_text}")





